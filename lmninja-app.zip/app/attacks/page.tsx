import { AttackLibrary } from "@/components/attack-library"

export default function AttacksPage() {
  return <AttackLibrary />
}
