import { DeveloperHub } from "@/components/developer-hub"

export default function DeveloperPage() {
  return <DeveloperHub />
}
