import { Settings } from "@/components/settings"

export default function SettingsPage() {
  return <Settings />
}
