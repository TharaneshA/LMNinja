import { LMNinjaInterface } from "@/components/lmninja-interface"

export default function HomePage() {
  return <LMNinjaInterface />
}
